# generate_data.py
# Creates fake but realistic banking loan data
# Same structure as Fifth Third's loan_portfolio_daily table

import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta

fake = Faker()
random.seed(42)

def generate_loan_data(n=10000):
    """
    Generate synthetic loan portfolio data
    Mimics structure of Teradata EDW loan tables
    """
    segments = ['RETAIL', 'COMMERCIAL', 'MORTGAGE', 'CARD']
    statuses = ['A', 'A', 'A', 'D', 'C']  # mostly Active
    products = ['HOME_LOAN', 'PERSONAL', 'AUTO', 'CREDIT_CARD', 'BUSINESS']

    data = []
    for i in range(n):
        origination = fake.date_between(start_date='-5y', end_date='-1y')
        maturity    = origination + timedelta(days=random.randint(365, 3650))
        balance     = round(random.uniform(10000, 5000000), 2)
        pd_score    = round(random.uniform(0.01, 0.35), 4)
        dpd         = random.choices([0,0,0,0,30,60,90,120], k=1)[0]

        data.append({
            'account_id'       : f'ACC{str(i+1).zfill(7)}',
            'cif_id'           : f'CIF{str(random.randint(1,5000)).zfill(7)}',
            'segment'          : random.choice(segments),
            'product_type'     : random.choice(products),
            'balance'          : balance,
            'pd_score'         : pd_score,
            'lgd_estimate'     : round(random.uniform(0.2, 0.8), 4),
            'dpd'              : dpd,
            'status'           : random.choice(statuses),
            'origination_date' : origination,
            'maturity_date'    : maturity,
            'branch_code'      : f'BR{str(random.randint(1,50)).zfill(3)}',
            'snap_date'        : datetime.today().date()
        })

    return pd.DataFrame(data)

if __name__ == "__main__":
    import os
    os.makedirs('data', exist_ok=True)
    df = generate_loan_data(10000)
    df.to_csv('data/raw_loans.csv', index=False)
    print(f"Generated {len(df)} loan records")
    print(df.head())
    print(df.dtypes)
