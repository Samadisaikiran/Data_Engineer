# etl_pipeline.py
# Main ETL pipeline
# Mirrors the SAS DATA step cleaning you see in production at Fifth Third Bank

import pandas as pd
from sqlalchemy import create_engine
from datetime import datetime
import logging
import os

# Create logs directory if not exists
os.makedirs('logs', exist_ok=True)

# Setup logging — like your SAS job logs
logging.basicConfig(
    filename=f'logs/etl_{datetime.today().strftime("%Y%m%d")}.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
log = logging.getLogger()

# ============================================================
# EXTRACT — read raw data
# Equivalent: SAS reading from Teradata via LIBNAME
# ============================================================
def extract(filepath):
    log.info(f"EXTRACT: Reading from {filepath}")
    df = pd.read_csv(filepath)
    log.info(f"EXTRACT: {len(df)} rows read")
    print(f"Extracted {len(df)} rows")
    return df

# ============================================================
# TRANSFORM — clean and derive features
# Equivalent: SAS DATA step at Fifth Third
# ============================================================
def transform(df):
    log.info("TRANSFORM: Starting data cleaning")
    raw_count = len(df)

    # Rule 1: Keep only active accounts
    # Same as: where status = 'A' in SAS
    df = df[df['status'] == 'A'].copy()
    log.info(f"TRANSFORM: After active filter — {len(df)} rows")

    # Rule 2: Handle nulls — same as SAS COALESCE
    df['balance']      = df['balance'].fillna(0)
    df['pd_score']     = df['pd_score'].fillna(0.05)   # default 5% PD
    df['lgd_estimate'] = df['lgd_estimate'].fillna(0.45)

    # Rule 3: Cap outliers
    # Same as: if dpd > 365 then dpd = 365 in SAS
    df['dpd']     = df['dpd'].clip(upper=365)
    df['balance'] = df['balance'].clip(lower=0)

    # Rule 4: Derive new columns
    # Same as your SAS DATA step derived fields
    df['ead']           = df['balance'] * 1.1
    df['expected_loss'] = (df['pd_score'] * df['lgd_estimate'] * df['ead']).round(2)

    # Rule 5: DPD bucket classification — banking standard
    def dpd_bucket(dpd):
        if dpd == 0:        return 'CURRENT'
        elif dpd <= 30:     return 'DPD_30'
        elif dpd <= 60:     return 'DPD_60'
        elif dpd <= 90:     return 'DPD_90'
        else:               return 'DPD_90_PLUS'

    df['dpd_bucket']     = df['dpd'].apply(dpd_bucket)
    df['load_timestamp'] = datetime.now()

    log.info(f"TRANSFORM: Complete. {raw_count} -> {len(df)} rows after cleaning")
    print(f"Transformed: {raw_count} -> {len(df)} rows")
    return df

# ============================================================
# VALIDATE — data quality checks
# Equivalent: your daily SQL validation at Fifth Third
# ============================================================
def validate(df):
    log.info("VALIDATE: Running data quality checks")
    errors = []

    # Check 1: Row count not zero
    if len(df) == 0:
        errors.append("CRITICAL: Zero rows after transform")

    # Check 2: No nulls in key columns
    key_cols = ['account_id', 'balance', 'pd_score', 'segment']
    for col in key_cols:
        null_count = df[col].isnull().sum()
        if null_count > 0:
            errors.append(f"ERROR: {null_count} nulls in {col}")

    # Check 3: account_id must be unique
    dupes = df['account_id'].duplicated().sum()
    if dupes > 0:
        errors.append(f"ERROR: {dupes} duplicate account_ids")

    # Check 4: balance must be positive
    neg_bal = (df['balance'] < 0).sum()
    if neg_bal > 0:
        errors.append(f"ERROR: {neg_bal} negative balances")

    # Check 5: pd_score between 0 and 1
    invalid_pd = ((df['pd_score'] < 0) | (df['pd_score'] > 1)).sum()
    if invalid_pd > 0:
        errors.append(f"ERROR: {invalid_pd} invalid pd_scores")

    if errors:
        for e in errors:
            log.error(f"VALIDATE: {e}")
        raise ValueError(f"Validation failed: {errors}")

    log.info(f"VALIDATE: All checks passed. {len(df)} rows validated.")
    print(f"Validation passed: {len(df)} rows clean")
    return True

# ============================================================
# LOAD — write to PostgreSQL
# Equivalent: writing to /sasdata/staged/ at Fifth Third
# ============================================================
def load(df):
    log.info("LOAD: Connecting to PostgreSQL")

    # Connection string — like your LIBNAME in SAS
    # Update password if you set a different one during PostgreSQL install
    engine = create_engine(
        'postgresql://postgres:admin123@localhost:5432/bank_etl'
    )

    df.to_sql(
        name      = 'loan_portfolio_staged',
        con       = engine,
        if_exists = 'replace',
        index     = False,
        chunksize = 1000
    )

    log.info(f"LOAD: {len(df)} rows written to loan_portfolio_staged")
    print(f"Loaded {len(df)} rows to PostgreSQL")
    return engine

# ============================================================
# MAIN — orchestrate the pipeline
# Equivalent: Control-M/TWS triggering the SAS job
# ============================================================
if __name__ == "__main__":
    print("=" * 50)
    print("LOAN PORTFOLIO ETL PIPELINE STARTING")
    print(f"Run date: {datetime.today().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)

    try:
        # Step 1: Extract
        df_raw = extract('data/raw_loans.csv')

        # Step 2: Transform
        df_clean = transform(df_raw)

        # Step 3: Validate
        validate(df_clean)

        # Step 4: Load
        engine = load(df_clean)

        print("\nPIPELINE COMPLETED SUCCESSFULLY")
        log.info("PIPELINE: Completed successfully")

    except Exception as e:
        print(f"\nPIPELINE FAILED: {e}")
        log.error(f"PIPELINE FAILED: {e}")
