# Loan Portfolio ETL Pipeline

End-to-end ETL pipeline processing synthetic banking loan data
using Python, Pandas, PostgreSQL, and SQL.

## Why I built this

I support production SAS ETL pipelines at Fifth Third Bank
(top-15 US commercial bank) that process millions of loan
records nightly. This project replicates that same ETL
pattern using open-source tools — demonstrating that I
understand the logic, not just the SAS syntax.

## What it does

```
Raw CSV (10,000 synthetic loan records)
    ↓ Extract    (Python reads CSV)
    ↓ Transform  (Pandas — null handling, capping, feature derivation)
    ↓ Validate   (5 automated data quality checks)
    ↓ Load       (PostgreSQL via SQLAlchemy)
    ↓ Analyse    (SQL — window functions, CTEs, aggregations)
```

## Tech stack

| Tool | Purpose |
|------|---------|
| Python 3.11 | Core language |
| Pandas | Data transformation (like SAS DATA step) |
| SQLAlchemy | DB connection (like SAS LIBNAME) |
| PostgreSQL | Target database |
| SQL | Advanced queries — window functions, CTEs |
| Git | Version control |

## Project structure

```
loan-etl-pipeline/
├── generate_data.py       # Creates 10,000 synthetic loan records
├── etl_pipeline.py        # Main ETL — extract, transform, validate, load
├── analysis_queries.sql   # 6 SQL queries for portfolio analysis
├── requirements.txt       # Python dependencies
├── .gitignore
├── README.md
├── data/
│   └── .gitkeep           # raw_loans.csv generated here (gitignored)
└── logs/
    └── .gitkeep           # Pipeline logs generated here (gitignored)
```

## How to run

### Step 1: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Create PostgreSQL database
Open PostgreSQL client and run:
```sql
CREATE DATABASE bank_etl;
```

### Step 3: Generate synthetic loan data
```bash
python generate_data.py
```

### Step 4: Run the ETL pipeline
```bash
python etl_pipeline.py
```

### Step 5: Run SQL analysis queries
Open `analysis_queries.sql` in any PostgreSQL client (pgAdmin, DBeaver, or psql)
and run the queries against the `bank_etl` database.

## Expected output

```
==================================================
LOAN PORTFOLIO ETL PIPELINE STARTING
Run date: 2026-03-22 14:30:00
==================================================
Extracted 10000 rows
Transformed: 10000 -> 8523 rows after cleaning
Validation passed: 8523 rows clean
Loaded 8523 rows to PostgreSQL

PIPELINE COMPLETED SUCCESSFULLY
```

## Key concepts demonstrated

- ETL pipeline design and execution
- Data cleaning and transformation (Pandas)
- Null handling, outlier capping, feature derivation
- 5 automated data quality validation checks
- Database connectivity via SQLAlchemy
- Advanced SQL: window functions (RANK, LAG, SUM OVER)
- Advanced SQL: CTEs (Common Table Expressions)
- DPD bucket classification (banking domain)
- Production-style pipeline logging
- Expected Loss calculation (PD x LGD x EAD)

## SAS to Python mapping

| SAS (production) | Python (this project) |
|---|---|
| LIBNAME teradata | SQLAlchemy create_engine |
| DATA step WHERE | df[df['status']=='A'] |
| COALESCE(col, 0) | df['col'].fillna(0) |
| IF dpd > 365 THEN dpd = 365 | df['dpd'].clip(upper=365) |
| PROC MEANS by segment | df.groupby('segment').agg() |
| SAS job log | Python logging module |
| /sasdata/staged/ | PostgreSQL table |

## Background

I currently manage SAS Grid infrastructure at Fifth Third Bank
supporting 300+ nightly batch jobs and 100+ analysts.
This project demonstrates the development side of data
engineering using the same banking domain knowledge.

## Author

**Saikiran Samadi**
Data Engineer | SAS Platform Engineer
LinkedIn: www.linkedin.com/in/samadi-saikiran
