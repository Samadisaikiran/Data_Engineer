-- analysis_queries.sql
-- Advanced SQL queries for loan portfolio analysis
-- Same validation and reporting logic as Teradata EDW queries at Fifth Third Bank

-- ============================================================
-- Query 1: Portfolio summary by segment
-- Equivalent: PROC MEANS by segment in SAS
-- ============================================================
SELECT
    segment,
    COUNT(*)                             AS loan_count,
    SUM(balance)                         AS total_balance,
    ROUND(AVG(pd_score)::numeric, 4)     AS avg_pd_score,
    SUM(expected_loss)                   AS total_expected_loss,
    ROUND(AVG(expected_loss)::numeric,2) AS avg_expected_loss
FROM loan_portfolio_staged
GROUP BY segment
ORDER BY total_balance DESC;


-- ============================================================
-- Query 2: Window function — rank accounts by balance within segment
-- Advanced SQL pattern — window functions you are learning now
-- ============================================================
SELECT
    account_id,
    segment,
    balance,
    pd_score,
    RANK() OVER (
        PARTITION BY segment
        ORDER BY balance DESC
    )                                    AS rank_in_segment,
    SUM(balance) OVER (
        PARTITION BY segment
    )                                    AS segment_total_balance,
    ROUND(
        balance / SUM(balance) OVER (PARTITION BY segment) * 100
    , 2)                                 AS pct_of_segment
FROM loan_portfolio_staged
WHERE status = 'A'
ORDER BY segment, rank_in_segment
LIMIT 20;


-- ============================================================
-- Query 3: DPD bucket analysis
-- Equivalent: daily AML and risk validation check at Fifth Third
-- ============================================================
SELECT
    dpd_bucket,
    COUNT(*)                              AS account_count,
    SUM(balance)                          AS total_balance,
    ROUND(AVG(pd_score)::numeric, 4)      AS avg_pd,
    ROUND(SUM(expected_loss)::numeric, 2) AS total_el
FROM loan_portfolio_staged
GROUP BY dpd_bucket
ORDER BY
    CASE dpd_bucket
        WHEN 'CURRENT'      THEN 1
        WHEN 'DPD_30'       THEN 2
        WHEN 'DPD_60'       THEN 3
        WHEN 'DPD_90'       THEN 4
        WHEN 'DPD_90_PLUS'  THEN 5
    END;


-- ============================================================
-- Query 4: CTE — high risk account identification
-- Advanced SQL — CTE pattern you are learning now
-- ============================================================
WITH high_risk AS (
    SELECT
        account_id,
        segment,
        balance,
        pd_score,
        expected_loss,
        dpd_bucket
    FROM loan_portfolio_staged
    WHERE pd_score > 0.20
      AND dpd_bucket != 'CURRENT'
),
risk_summary AS (
    SELECT
        segment,
        COUNT(*)           AS high_risk_count,
        SUM(balance)       AS high_risk_balance,
        SUM(expected_loss) AS high_risk_el
    FROM high_risk
    GROUP BY segment
)
SELECT *
FROM risk_summary
ORDER BY high_risk_balance DESC;


-- ============================================================
-- Query 5: LAG window function — compare consecutive records
-- ============================================================
SELECT
    account_id,
    segment,
    balance,
    pd_score,
    LAG(pd_score, 1) OVER (
        PARTITION BY segment
        ORDER BY account_id
    )                                    AS prev_pd_score,
    ROUND(
        (pd_score - LAG(pd_score, 1) OVER (
            PARTITION BY segment
            ORDER BY account_id)
        )::numeric, 4
    )                                    AS pd_change
FROM loan_portfolio_staged
ORDER BY segment, account_id
LIMIT 20;


-- ============================================================
-- Query 6: Data validation check
-- Exactly what you do at Fifth Third daily after batch run
-- ============================================================
SELECT 'Total rows'          AS check_name, COUNT(*)::text AS result
FROM loan_portfolio_staged

UNION ALL
SELECT 'Active accounts',    COUNT(*)::text
FROM loan_portfolio_staged WHERE status = 'A'

UNION ALL
SELECT 'Null balances',      COUNT(*)::text
FROM loan_portfolio_staged WHERE balance IS NULL

UNION ALL
SELECT 'Negative balances',  COUNT(*)::text
FROM loan_portfolio_staged WHERE balance < 0

UNION ALL
SELECT 'Invalid PD scores',  COUNT(*)::text
FROM loan_portfolio_staged WHERE pd_score < 0 OR pd_score > 1

UNION ALL
SELECT 'Duplicate accounts', COUNT(*)::text
FROM (
    SELECT account_id
    FROM loan_portfolio_staged
    GROUP BY account_id
    HAVING COUNT(*) > 1
) dups;
